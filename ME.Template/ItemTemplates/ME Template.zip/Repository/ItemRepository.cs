﻿namespace $rootnamespace$;
public class $safeitemname$Repository : BaseRepository<$safeitemname$> {
	public $safeitemname$Repository() { }
}