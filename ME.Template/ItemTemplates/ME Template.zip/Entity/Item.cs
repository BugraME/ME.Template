﻿namespace $rootnamespace$;
public class $safeitemname$ : BaseEntity {

}