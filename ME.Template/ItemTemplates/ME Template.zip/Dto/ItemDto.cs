﻿namespace $rootnamespace$;
public class $safeitemname$ : BaseDto {

}