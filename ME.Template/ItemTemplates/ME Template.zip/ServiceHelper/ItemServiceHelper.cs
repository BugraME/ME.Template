﻿namespace $rootnamespace$;
public class $safeitemname$Service : BaseService<$safeitemname$Repository,$safeitemname$Dto,$safeitemname$> {
	public $safeitemname$Service() { }
}